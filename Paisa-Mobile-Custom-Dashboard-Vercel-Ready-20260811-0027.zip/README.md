# Paisa — Personal Money Tracker

Paisa is a private, local-first personal finance PWA for tracking INR income, expenses, salary allocations, credit-card liabilities, EMIs, funds, investments, one-time income, side-hustle money, and savings goals. It uses the supplied ₹80k personal money map as an editable default template.

## Current capabilities

- Responsive overview with budget health, projected spending, account plans, category totals, and recent activity.
- Expense and income creation, editing, deletion, status handling, search, and filters.
- Editable ₹80k salary map: ₹45k living, ₹15k funds, ₹12k investments, and ₹8k wants.
- Exact living plan with rent, food, phone EMI, education-loan EMI, utilities, transport, and essentials.
- Axis and SBI card limits, utilization targets, outstanding liability, and payments without double-counting.
- Emergency and Vietnam funds, one-time joining money, side-hustle reserves, loans, timeline, and priority waterfall.
- A fully flexible Money Plan builder: rename and reorder every module, hide or restore built-ins without losing data, and make any module available every month or only in one selected month.
- Custom budget, goal, and checklist modules with editable titles, descriptions, colors, line items, planned/current amounts, completion state, and permanent deletion.
- A separate Notion-style Workspace with multiple pages, templates, reusable blocks, drag-and-drop ordering, half/full-width layouts, duplication, archive, and restore.
- Flexible collections that switch between table, board, calendar, and card views while retaining one shared set of records.
- Live Workspace blocks for monthly KPIs, transactions, dedicated funds, investments, and category spending charts.
- A reusable dashboard-page system: promote any Workspace page to Overview, automatically add missing dashboard essentials, customize its block order and widths, or restore the original Overview without deleting the page.
- Dashboard blocks for the monthly money plan, credit position, goals and funds, KPIs, transactions, charts, checklists, notes, callouts, and flexible collections.
- Account and category plans with integer-paise calculations.
- Spending distribution, budget comparison, recurring-payment context, and a savings goal.
- Versioned IndexedDB persistence with validated JSON backup/restore and CSV export.
- Light, dark, and system themes.
- Installable offline PWA with locally bundled assets.

The supplied salary, card, EMI, fund, and travel values are defaults rather than hard-coded rules. Use **Customize plan** to shape Money Plan and use the separate **Workspace** tab for free-form pages and views. Change amounts directly on the Money Plan screen, record actual activity through Transactions, and use Settings to export, restore, or reset the template.

## Run locally

Requirements: Node.js 24 or another version supported by the pinned toolchain.

```powershell
npm install
npm run dev
```

Open the local URL printed by Vite.

## Verification

```powershell
npm run typecheck
npm test
npm run build
```

The production PWA is generated in `dist/`.

## Mobile and Vercel release

The application uses a five-destination mobile navigation bar, safe-area-aware layouts, touch-sized controls, an edge-to-edge transaction editor, responsive Workspace views, and a dedicated install experience in Settings. Settings remains accessible from the profile avatar so the primary navigation stays focused on daily money tasks.

For a clean deployment from another computer, follow [VERCEL_DEPLOYMENT.md](VERCEL_DEPLOYMENT.md). The checked-in `vercel.json` contains the Vite build, SPA fallback, cache, and security-header configuration used by the release package.

## Architecture

```text
src/
  components/   Shared navigation, forms, icons, and transaction UI
  data/         Default data, IndexedDB persistence, validation, import/export
  domain/       Typed financial models, paise helpers, calculations, tests
  features/     Dashboard, transactions, Money Plan, Workspace, analysis, and settings
```

Workspace pages are stored inside the same validated backup as the financial data. Live Workspace blocks read the shared transactions; deleting a Workspace block never deletes its underlying transactions.

All monetary values are stored as integer paise. Cleared expenses affect actual spending; pending expenses are shown separately. Fund contributions, investments, and card payments have distinct transaction purposes. Card purchases count as spending once, while statement payments reduce the liability without creating a duplicate expense.

## Privacy and limitations

Data is stored in the current browser profile and is not sent to a server. Browser storage can still be cleared by the user, browser, or device policy, so regular JSON backups are recommended. This build does not connect to banks, synchronize across devices, or provide financial advice.
